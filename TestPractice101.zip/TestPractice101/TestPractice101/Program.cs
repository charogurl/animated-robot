﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestPractice101
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Browser.Initialize();

            //Open Application
            Browser.NavigateToPage();

            //Login
            BasePage.Login("0468827174", "theHoff34");

            //Navigate to My Settings Page
            BasePage.NavigateToMySettings();
            
            //Logout
            BasePage.Logout();

            //Close Application
            Browser.ClosePage();

            

        }
    }
}
