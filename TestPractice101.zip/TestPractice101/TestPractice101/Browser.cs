﻿using System;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;

namespace TestPractice101
{
    public class Browser
    {
        public static RemoteWebDriver MainDriver;

        public static void Initialize()
        {
            MainDriver = new FirefoxDriver();
            MainDriver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(5));
        }

        
        public static void ClosePage()
        {
            MainDriver.Quit();

            Console.WriteLine("Test Complete. Thank you Charo");
        }

        /// <summary>
        /// This method Opens the Application
        /// </summary>
        public static void NavigateToPage()
        {
            MainDriver.Navigate().GoToUrl("https://www.amaysim.com.au/");
        }
    }
}