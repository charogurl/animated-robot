﻿using System;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace TestPractice101
{
    public class BasePage
    {
        public static RemoteWebDriver driver = Browser.MainDriver;

        public static void Login(string username, string password)
        {
            driver.FindElement(By.CssSelector("a[data-js*='login']")).Click();
            System.Threading.Thread.Sleep(3000);

            driver.SetText("my_amaysim2_user_session_login", username);
            driver.SetText("password", password);

            driver.FindElement(By.CssSelector("input#login_button")).Click();
            System.Threading.Thread.Sleep(5000); 
        }

        public static void NavigateToMySettings()
        {
            var activationPopUp = driver.IsElementVisible(By.CssSelector("div[id*='welcome_popup']"));
            
            if (activationPopUp != null)
            {
                driver.FindElement(By.CssSelector("div[id*='welcome_popup']")).FindElement(By.CssSelector("a[class*='close-reveal-modal']")).Click();
            }

            driver.FindElement(By.CssSelector("a[href*='/my-account/my-amaysim/settings']")).Click();
            Thread.Sleep(3000);

            driver.FindElement(By.CssSelector("a#edit_settings_call_forwarding")).Click();

            Thread.Sleep(6000);

            var confirmationPopUp = driver.IsElementVisible(By.CssSelector("div[class*='form_confirm_popup reveal-modal padding-none open']"));

            if (confirmationPopUp != null)
            {
                confirmationPopUp.FindElement(By.LinkText("Confirm")).Click();
            }

            var callForwardingNumberVisible = driver.IsElementVisible(By.CssSelector("input#my_amaysim2_setting_call_divert_number"));
            if (callForwardingNumberVisible == null)
            {
                driver.FindElement(By.CssSelector("input[id*='my_amaysim2_setting_call_divert_true']")).Click();
                Thread.Sleep(5000);
            }

            driver.SetText("my_amaysim2_setting_call_divert_number", "0412" + RandNum(6));

            driver.FindElement(By.CssSelector("input[name*='commit']")).Click();

            Thread.Sleep(7000);
                
            var callForwardingValidation = driver.FindElement(By.CssSelector("div[class*='form_info_popup reveal-modal padding-none open']"));

            if (callForwardingValidation == null) return;
            
            var isSuccessful = callForwardingValidation.Text.ToLower().Contains("success");
                    
            Console.WriteLine(isSuccessful ? "Call Forwarding update is SUCCESSFUL" : "Call Forwarding update FAILED");

            Thread.Sleep(3000);

            driver.FindElement(By.CssSelector("div[class*='form_info_popup reveal-modal padding-none open']")).FindElements(By.TagName("a"))[1].Click();
        }

        public static string RandNum(int length)
        {
            Thread.Sleep(100);
            var randomNumber = new Random();
            var rand1 = (UInt64)randomNumber.Next(100000000, 999999999);
            var rand2 = (UInt64)randomNumber.Next(100000000, 999999999);
            return (rand1 * rand2).ToString().Remove(length);
        }

        public static void Logout()
        {
            driver.FindElement(By.CssSelector("a[class*='uluru logout-link']")).Click();
            System.Threading.Thread.Sleep(5000);
        }
    }
}