﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace TestPractice101
{
    public static class Controls
    {
        public static void SetText(this ISearchContext driver, string pattern, string text)
        {
            driver.FindElement(By.CssSelector("input[id*='" + pattern + "']")).Clear();
            driver.FindElement(By.CssSelector("input[id*='" + pattern + "']")).SendKeys(text);
        }

        /// <summary> Check element if Visible and Present 
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="by"></param>
        /// <returns></returns>
        public static IWebElement IsElementVisible(this ISearchContext driver, By by)
        {
            try
            {
                Browser.MainDriver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(15));

                var webElement = driver.FindElement(by);

                if (webElement.Displayed && webElement.Enabled)
                {
                    Browser.MainDriver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(30));

                    return webElement;
                }

                Browser.MainDriver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(30));

            }
            catch (Exception e)
            {

            }
            //}

            return null;
        }

    }
}
