This purpose of this project is to test the Amaysim managing settings and make sure that Call Forwarding is working.

Note: This script is written in Selenium Webdriver and C# as the author has no expertise in the required programming languages.


Instruction:
1. Unzip the file and save on your C:/>
2. Double click on the Application (TestPractice101)
3. Script will just run automatically.
